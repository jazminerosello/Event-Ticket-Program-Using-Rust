//ROSELLO, MA. JAZMINE P.
//CMSC 124-ST7L
//This program is a that allows users to add events and let customers buy tickets for said events (like smtickets). Since you will be using the Vector collection of Rust, there must be no limit to the number of artists and/or customers that you can add.

use std::io; //library for standard input output

struct Artist_Event {
    event_id: u32,
    event_title: String,
    artist: String,
    datetime: String,
    ticket_price: f64,
    stock: u32,
}

struct Customer {
    name: String,
    tickets_bought: Vec<String>,
    total_cost: f64,
}

//this will ask for users choice for menu and will return the ch variable where the users choice is in to main
fn menu() -> isize {
    print!("\n==================== MENU ====================\n");
    println!("[1] Add Event Details");
    println!("[2] Buy Tickets");
    println!("[3] Edit Event Details");
    println!("[4] Delete Event");
    println!("[5] View All Events");
    println!("[6] View All Customers");
    println!("[7] Exit\n");

    let mut choice: String = String::new();
    println!("Choice: ");
    io::stdin().read_line(&mut choice).expect("Error");
    let ch: isize = choice.trim().parse().expect("Error"); //convert it into isize or integer

    return ch;
}

fn add_events(v: &mut Vec<Artist_Event>) {
    let mut id = String::new();
    let mut title = String::new();
    let mut artist = String::new();
    let mut datetime = String::new();
    let mut ticketprice = String::new();
    let mut stock = String::new();

    println!("\n>>>Please fill the following for Event Details...");

    //ask for event id of the events user wants to add
    println!("\nEvent Id: ");
    io::stdin().read_line(&mut id).expect("Error");
    let id2: u32 = id.trim().parse().expect("Error"); //convert into iu32 integer

    let checker: u32 = check_existing(id2, v); //call the check_existing function to know if the id is already in the system

    if checker == 0 {
        //if it returns 0, there is no such id yet in the system so we will add this event

        //ask for event title, artist, date and time, ticket price being converted to f64, stock being converted to u32
        println!("\nEvent Title: ");
        io::stdin().read_line(&mut title).expect("Error");

        println!("\nEvent Artist: ");
        io::stdin().read_line(&mut artist).expect("Error");

        println!("\nEvent Date and Time (Format: Month Day, Year Hour(AM/PM)): ");
        io::stdin().read_line(&mut datetime).expect("Error");

        println!("\nEvent Ticket Price: ");
        io::stdin().read_line(&mut ticketprice).expect("Error");
        let ticket: f64 = ticketprice.trim().parse().expect("Error");

        println!("\nEvent Stock: ");
        io::stdin().read_line(&mut stock).expect("Error");
        let st: u32 = stock.trim().parse().expect("Error");

        //declare new variable that is a structure of Artist_event then assigned respective variables to the members of the structure
        let new = Artist_Event {
            event_id: id2,
            event_title: title,
            artist: artist,
            datetime: datetime,
            ticket_price: ticket,
            stock: st,
        };
        v.push(new); //push the new variable to the vector of events
        print!("\n>>> Successfuly added an event\n");
    } else {
        //if it is already existing in the system, print prompt error
        print!("\n>>> EVENT ID already an EXISTING.\n");
    }
}

//this simply prints the contents of event vector
fn print_events(v: &mut Vec<Artist_Event>) {
    if v.len() == 0 {
        //check if the vector is empty
        print!("\n>>> There are still no events yet!\n\n");
    } else {
        //else print the contents
        print!("\nHere are the list of events:\n");

        for i in v {
            println!("\n======== Event ID: {} ========", i.event_id);
            print!("Title: {}", i.event_title);
            print!("Artist: {}", i.artist);
            print!("Date and Time: {}", i.datetime);
            print!("Ticket Price: {}\n", i.ticket_price);
            println!("Stock: {}", i.stock);
        }
    }
}

//this delete the events
fn delete_events(v: &mut Vec<Artist_Event>) {
    let mut del = String::new();

    print_events(v); //call the print_events function to print events

    if v.len() != 0 {
        //check if the vector is not empty
        //get the id users want to be deleted
        println!("\nEvent Id to be DELETED: ");
        io::stdin().read_line(&mut del).expect("Error");
        let delete_id: u32 = del.trim().parse().expect("Error"); //convert ot u32 integer

        if let Some(index) = get_index(delete_id, v) {
            //if get_index function returns something
            v.remove(index); //continue in removing the return index to the vector of event
            println!("\n>>> Event with ID {} has been deleted.", delete_id);
        } else {
            //if it does not return, then the id users want to delete is not in the vector
            println!("\n>>> Event with ID {} not found.", delete_id);
        }
    }
}

//this edit the details of an event in the vector
fn edit_details(v: &mut Vec<Artist_Event>) {
    let mut id = String::new();
    let mut checker = 0;

    if v.len() != 0 {

        print_events(v);
        //get the id to be deleted
        println!("\nEvent Id to be EDITED: ");
        io::stdin().read_line(&mut id).expect("Error");
        let id_to_be_edit: u32 = id.trim().parse().expect("Error"); //convert to u32

        //check every event in the event vector by iterating them
        for i in v {
            if i.event_id == id_to_be_edit {
                //if the i.event_id is equal to the id users want ot edit
                checker = 1; //set the checker into 1, meaning id is in the system
                let mut new_datetime = String::new();
                let mut price = String::new();
                let mut new_stock = String::new();

                //then ask for new date and time, new ticket price, new stock
                println!("\nEvent Date and Time (Format: Month Day, Year Hour(AM/PM)): ");
                io::stdin().read_line(&mut new_datetime).expect("Error");

                println!("\nEvent Ticket Price: ");
                io::stdin().read_line(&mut price).expect("Error");
                let ticket: f64 = price.trim().parse().expect("Error");

                println!("\nEvent Stock: ");
                io::stdin().read_line(&mut new_stock).expect("Error");
                let st: u32 = new_stock.trim().parse().expect("Error");

                //set or update the members in this ith element in vector
                i.datetime = new_datetime;
                i.stock = st;
                i.ticket_price = ticket;

                print!("\n>>> Event Details Successfully Edited!\n");
                break;
            }
        }
        if checker == 0 {
            //if checker remains 0, it means id is not in the system
            let modified_id = id.replace("\n", "");
            print!("\n >>> Event id {} is not existing!\n", modified_id);
        }
    }else{
        print!("\n>>> There are no events yet!\n");
    }
}

//this simply prints available events
fn print_available_events(v: &mut Vec<Artist_Event>) {
    print!("\n------- EVENTS AVAILABLE -------:\n");
    let mut counter = 0;
    //it just prints all the elements in the vector event
    for i in v {
        let title_event = i.event_title.replace("\n", "");
        let artist_event = i.artist.replace("\n", "");
        counter += 1;
        print!(
            "[{}] {} ({}) - {}\n",
            counter,
            title_event,
            artist_event,
            i.ticket_price.to_string()
        );
    }
    print!("\n");
}

//this prints customer and their details in customer vector
fn print_customer(_c: &mut Vec<Customer>) {
    if _c.len() == 0 {
        print!("\n>>> There are no Customers yet!\n\n");
    } else {
        print!("Here are the list of Customers and their details:\n");
        //    let mut length = v.len();
        for i in _c {
            println!("\n================");
            print!("Customer Name: {}", i.name);
            print!("Tickets Bought:\n");
            for j in &i.tickets_bought {
                print!("\t- {}\n", j);
            }
            print!("\nTotal Cost: {}\n", i.total_cost);
        }
    }
}

//this checks if the customer is existing by using the checker and setting it to 1, if checker remains 0, it means customer is not in the system
fn check_customer_exisitng(name: &mut String, _c: &mut Vec<Customer>) -> u32 {
    let mut checker: u32 = 0;
    let n = name.to_uppercase();
    for i in _c {
        let check_name = &i.name.to_uppercase();
        if check_name.to_owned() == n {
            checker = 1;
            // println!("There is already an existing event.");
            break;
        }
    }
    return checker;
}

//this function does adding customer to the system if it is still not in the system
//if the customer is in the system, it just updates this customer total_cost adn add the event it wants to buy to the ticket_bought vector
fn buy_ticket(_c: &mut Vec<Customer>, v: &mut Vec<Artist_Event>) {
    let mut name = String::new();
    let mut tickets: Vec<String> = Vec::new();
    let mut cost: f64 = 0.0;
    let mut id = String::new();

    if v.len() != 0 {
        //check if the event vector is empty or not
        //ask for customer name
        println!("\nCustomer Name: ");
        io::stdin().read_line(&mut name).expect("Error");
        //call the check_customer_existing function to know if the customer name is in the system already
        let checker = check_customer_exisitng(&mut name, _c);

        print_available_events(v); //print the available events

        //ask for the id customer wants to buy
        println!("\nEnter EVENT ID you want to buy: ");
        io::stdin().read_line(&mut id).expect("Error");
        let id: u32 = id.trim().parse().expect("Error"); //convert into u32

        if let Some(index) = get_index(id, v) {
            //if get_index return something, meaning the id customer wants to buy ticket is existing
            if v[index].stock > 0 {
                //check if the stock is not 0
                //remove \n at the end of the strings so it will be printed in one line
                let id = v[index].event_id.to_string().replace("\n", "");
                let title_event = v[index].event_title.replace("\n", "");
                let date_event = v[index].datetime.replace("\n", "");
                let artist = v[index].artist.replace("\n", "");

                let t_b = id + "_" + &title_event + "_" + &date_event; //set t_b as the String to be push in the ticket_bought member
                cost += v[index].ticket_price; //put the ticket_price of the event to cost

                if checker == 1 {
                    //if customer is already in the system

                    let n = &name.to_uppercase();
                    //go to the customer element by iterating over the customer vector
                    for i in _c {
                        let check_name = &i.name.to_uppercase();
                        if check_name.to_owned() == n.to_owned() {
                            //simply push the t_b to the tickets_bought and update the total_cost of this customer
                            i.tickets_bought.push(t_b);
                            i.total_cost = cost + i.total_cost;
                            break;
                        }
                    }
                } else {
                    //if not yet, add the customer to the system
                    tickets.push(t_b); //push the t_b to tickets which is a vector of String
                                       //declare variable that is a structure of Customer then update or assigned respective values to the members
                    let _new = Customer {
                        name: name,
                        tickets_bought: tickets,
                        total_cost: cost,
                    };
                    _c.push(_new); //then push to the vector
                }

                v[index].stock = v[index].stock - 1; //decrement the stock of the event being bought by the customer

                print!("\n>>> You have successfully bought ticket for the event entitled {} by {} that is scheduled on {}.\n", title_event, artist, date_event);
            } else {
                //if the event ticket customer wants to buy is out of stock
                print!("\n >>> Event ticket is out of stock :<<\n");
            }
        } else {
            //if the id customer wants to buy ticket to is not existing
            println!("\n>>> Event with ID {} not found.", id);
        }
    } else {
        //if there are no events yet in the vector
        print!("\n>>> There are no events avaiable!\n");
    }
}

//this return index of the event if the event is found, returns none if not
fn get_index(id: u32, v: &mut Vec<Artist_Event>) -> Option<usize> {
    for (index, event) in v.iter().enumerate() {
        if id == event.event_id {
            return Some(index);
        }
    }
    None
}

//checks if the event is existing by returning 1 and 0 if not.
fn check_existing(id: u32, v: &mut Vec<Artist_Event>) -> u32 {
    let mut checker: u32 = 0;
    for i in v {
        if i.event_id == id {
            checker = 1;
            // println!("There is already an existing event.");
            break;
        }
    }
    return checker;
}

fn main() {
    // let counter
    let y: bool = true;
    //declare the vectors of event and customer
    let mut event_vector: Vec<Artist_Event> = Vec::new();
    let mut customer_vector: Vec<Customer> = Vec::new();

    //continue looping until 7 is chose
    while y == true {
        let c: isize = menu();
        if c == 1 {
            add_events(&mut event_vector);
        } else if c == 2 {
            buy_ticket(&mut customer_vector, &mut event_vector);
        } else if c == 3 {
            edit_details(&mut event_vector);
        } else if c == 4 {
            delete_events(&mut event_vector);
        } else if c == 5 {
            print_events(&mut event_vector);
        } else if c == 6 {
            print_customer(&mut customer_vector);
        } else if c == 7 {
            print!("\nThank you for using the system program. \nGoodbye!\n\n");
            break;
        } else {
            print!("\n>>>You have input valid for choice!\n");
        }
    }

    // }
}
